CREATE FUNCTION "allCidades"()
  RETURNS text
LANGUAGE SQL
AS $$
SELECT nome FROM cidades
$$;

