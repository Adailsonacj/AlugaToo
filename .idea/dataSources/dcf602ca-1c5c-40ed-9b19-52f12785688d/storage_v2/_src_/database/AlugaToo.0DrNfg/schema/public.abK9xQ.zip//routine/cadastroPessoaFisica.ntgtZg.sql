CREATE FUNCTION "cadastroPessoaFisica"(enbairro character varying, ennumero integer, enlongradouro character varying, encomplemento character varying, enidcidade integer, penome character varying, penascimento date, pfcpf character, pfrg character, usemail character varying, ussenha character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
 
 retornoEndereco INT; retornoPessoa INT; retornoPessoaF INT; condicao BOOLEAN;

BEGIN

INSERT INTO public.endereco(bairro, numero, longradouro, complemento, fk_id_cidade) VALUES ('centro', 4, 'Rua Jose', 'aaa', 5);
retornoEndereco := (SELECT MAX(id_endereco)FROM endereco);

INSERT INTO pessoa VALUES (peNome, peNascimento, retornoEndereco);
retornoPessoa = (SELECT MAX(id_pessoa)FROM pessoa);

INSERT INTO pessoa_fisica VALUES (pfCpf, pfRg, retornoPessoa);
retornoPessoaF = (SELECT MAX(id_pessoa_fisica)FROM pessoa_fisica);

INSERT INTO usuario VALUES (usEmail, usSenha, retornoPessoaF);


END
$$;

