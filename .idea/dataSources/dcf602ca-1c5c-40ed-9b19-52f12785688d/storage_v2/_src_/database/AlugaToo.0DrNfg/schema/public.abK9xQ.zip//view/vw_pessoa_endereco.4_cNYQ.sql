CREATE VIEW vw_pessoa_endereco AS
  SELECT ps.fk_id_endereco,
    en.id_endereco
   FROM pessoa ps,
    endereco en
  WHERE (ps.fk_id_endereco = en.id_endereco);

