CREATE FUNCTION produtolog()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
	INSERT INTO public.produtos_log(nome, descricao, valor, fk_idpessoafisica)VALUES (OLD.nome, OLD.descricao, OLD.valor, OLD.fk_idpessoafisica);
	RETURN NULL;
END;
$$;

