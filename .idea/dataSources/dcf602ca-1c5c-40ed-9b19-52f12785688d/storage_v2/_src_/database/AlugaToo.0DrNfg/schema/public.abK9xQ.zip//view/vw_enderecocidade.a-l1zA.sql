CREATE VIEW vw_enderecocidade AS
  SELECT cd.id_cidade,
    en.fk_id_cidade
   FROM cidades cd,
    endereco en
  WHERE (cd.id_cidade = en.fk_id_cidade);

