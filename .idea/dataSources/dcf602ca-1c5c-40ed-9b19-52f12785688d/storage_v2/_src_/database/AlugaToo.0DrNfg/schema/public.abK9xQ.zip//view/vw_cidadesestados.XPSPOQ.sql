CREATE VIEW vw_cidadesestados AS
  SELECT cd.fk_id_estado,
    es.id_estado
   FROM cidades cd,
    estados es
  WHERE (cd.fk_id_estado = es.id_estado);

