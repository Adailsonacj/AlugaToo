CREATE FUNCTION data_registro_usuario()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
	NEW.dataregistro = CURRENT_TIMESTAMP;
	RETURN NEW;
END;
$$;

