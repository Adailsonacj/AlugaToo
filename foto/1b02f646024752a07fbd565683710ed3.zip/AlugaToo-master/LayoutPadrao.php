<?php

class LayoutPadrao
{
    public static function TODO()
    {
        echo '<link href="node_modules/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
              <script src="node_modules/jquery/dist/jquery.js"></script>
              <script src="node_modules/popper.js/dist/umd/popper.js"></script>
              <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script> ';

    }
}

?>